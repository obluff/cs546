var express = require('express');
var exphbs  = require('express-handlebars');
var bcrypt = require('bcrypt');
const cookie = require("cookie-parser");

var users = require('./users');
var userLookup = users.userList;

var app = express();


app.use(require('body-parser').urlencoded({ extended: false }));
app.use(cookie());
app.use('/public', express.static('public'));
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');



app.get('/', (req, res) => {
  if(!(req.cookies.authorized)){
    res.render('login.hbs', {text: ''});
}
else{
  res.redirect('/private')
}
});

app.post('/login', async (req, res) => {
  const request = await req.body;
  console.log(request);
  var completed = false;
  if(userLookup.hasOwnProperty(request.username)){
    if(await bcrypt.compare(request.password, userLookup[request.username]['hashedPassword'])) {
      res.cookie('authorized', request.username);
      res.redirect('/private');
      completed = true;
    }
  }
  if(completed == false) res.render('login.hbs', {text: 'you failed to provide correct credentials'});  
});

app.get('/logout', (req, res) => {
  res.clearCookie('Authorized');
  res.render('login.hbs', {text: 'you have successfully logged out'});
});

app.get('/private', (req, res) => {
  if(!(req.cookies.authorized)){
    res.status(403).send('You gotta log in buddy');
    res.redirect('/');
  }
  if(!(userLookup.hasOwnProperty(req.cookies.authorized))) res.redirect('/', {text: 'some sort of error occured'})
  var data = userLookup[req.cookies.authorized]
  console.log(data);
  res.render('private.hbs', {firstName: data['firstName'], lastName: data['lastName'], profession: data['profession'], bio: data['bio']});
});

app.listen(3000, function () {
    console.log('express-handlebars server  listening on: 3000');
    if (process && process.send) process.send({done: true});
});
